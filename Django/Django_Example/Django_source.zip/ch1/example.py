import urllib2
print urllib2.urlopen("http://www.example.com").read()
